<?php
	header("content-Type: text/html; charset=gbk");
	include_once("functions/database.php");
	include_once("functions/is_login.php");
?>
<div class="container" style="width: 600px; margin:0 auto; margin-top: 20px;">
    <div class="news-list" >
	        <fieldset class="layui-elem-field layui-field-title" style="margin-top: 0px;">
			  <legend>�༭��λ - ���Ӹ�λ</legend>
			</fieldset>
			<form class="layui-form layui-form-pane" action="companyPosition_add_process.php" method="post">
			<div class="layui-form-item">
		    	<label class="layui-form-label">��λ����</label>
		    	<div class="layui-input-inline">
		      		<input type="text" name="pname" lay-verify="required" placeholder="������" autocomplete="off" class="layui-input">
		    	</div>
		    </div>
		    <div class="layui-form-item">
		  		<label class="layui-form-label">��λ����</label>
			   	<div class="layui-input-inline">
			    	<select name="ptype">
				        <option value="0" selected>��ѡ��</option>
				        <option value="�������">�������</option>
				        <option value="������">������</option>
				        <option value="������">������</option>
				        <option value="������">������</option>
				        <option value="������">������</option>
			      	</select>
			    </div>
		 	</div>
		  	<div class="layui-form-item">
		  		<label class="layui-form-label">��λ����</label>
			    <div class="layui-input-inline">
			    	<input type="text" name="pcount" lay-verify="required" placeholder="������" autocomplete="off" class="layui-input">
			    </div>
			</div>    
			<div class="layui-form-item">
		    	<label class="layui-form-label">��н</label>
			    <div class="layui-input-inline">
			    	<input type="text" name="psalary" lay-verify="required" placeholder="������" autocomplete="off" class="layui-input">
			    </div>
			</div>
		  	<div class="layui-form-item layui-form-text">
		   		<label class="layui-form-label">��ְҪ��</label>
		    	<div class="layui-input-block">
		     		<textarea name="pquirment" placeholder="" class="layui-textarea"></textarea>
		    	</div>
		  	</div>
		  	<div class="layui-form-item">
		    	<button class="layui-btn" lay-submit="" lay-filter="demo2">����</button>
		    	
				<a href = "index.php?url=companyPosition.php">
					<font color="white">
						<button type="button" class="layui-btn layui-btn">����</button>
					</font>
				</a>
		  	</div>
		</form>
	</div>
</div>
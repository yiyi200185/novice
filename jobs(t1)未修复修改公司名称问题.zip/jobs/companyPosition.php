<?php
	header("content-Type: text/html; charset=gbk");
	include_once("functions/database.php");
	include_once("functions/page.php");
	include_once("functions/is_login.php");
	if(isset($_SESSION["name"]))
	{
		$cname = $_SESSION["name"];
	}
	$search_sql = "select * from COMPANY_POSITION where DELETE_FLAG = 0 and P_C_NAME = '$cname' order by P_ID desc";
	get_connection();
	$result_news = mysql_query($search_sql);
	$total_records = mysql_num_rows($result_news);
	$page_size = 5;
	if(isset($_GET["page_current"])){
		$page_current = $_GET["page_current"];
	}else{
		$page_current = 1;
	}
	$start = ($page_current - 1) * $page_size;
	$search_sql = "select * from COMPANY_POSITION where DELETE_FLAG = 0 and P_C_NAME = '$cname' order by P_ID desc limit $start, $page_size";
	$result_set = mysql_query($search_sql);
	close_connection();
?>
<div class="container">
    <div class="news-list">
        <div class="news-list-item">
	        <fieldset class="layui-elem-field layui-field-title" style="margin-top: 0px;">
		 		<legend>�༭��λ</legend>
			</fieldset> 
        	<a href="index.php?url=companyPosition_add.php" class="layui-btn layui-btn-radius">���Ӹ�λ+</a><br>
			<br>
			<table class="layui-table">
				<colgroup>
					<col width="150">
					<col width="200">
					<col width="120">
					<col width="300">
					<col width="80">
					<col width="230">
				</colgroup>
				<thead>
					<tr>
						<th>��λID</th>
					    <th>��λ����</th>
					    <th>��λ����</th>
					    <th>��ְ����</th>
					    <th>��н</th>
					    <th>����</th>
					</tr> 
				</thead>
				<tbody>
		        <?php
					while($row = mysql_fetch_array($result_set)){
				?>
				<tr>
					<td><?php echo $row['P_ID']?></td>
					<td><?php echo $row['P_NAME']?></td>
					<td><?php echo $row['P_TYPE']?></td>
					<td><?php echo $row['P_REQUIREMENT']?></td>
					<td><?php echo $row['P_SALARY']?></td>
					<td>
						<a href = "index.php?url=companyPosition_edit.php&P_ID=<?php echo $row['P_ID']?>&page_current=<?php echo $page_current?>" class="layui-btn ">�༭</a>
						<a href = "index.php?url=companyPosition_delete.php&P_ID=<?php echo $row['P_ID']?>&page_current=<?php echo $page_current?>" class="layui-btn " onclick = "return confirm('ȷ��ɾ��������λ��?');">ɾ��</a> 
					</td>
				</tr>	            
		        <?php
					}
				?>
				</tbody>
			</table>
		</div>
        <div class="divpage">
   			<?php
	   			if(mysql_num_rows($result_set) != 0)
	   			{
					$url = $_SERVER["PHP_SELF"]."?url=companyPosition.php";
					page($total_records, $page_size, $page_current, $url, null ,null);
				}
			?>
        </div>
	</div>
</div>





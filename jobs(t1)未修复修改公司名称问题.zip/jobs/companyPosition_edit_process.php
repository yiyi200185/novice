<?php
	include_once("functions/database.php");
	include_once("functions/is_login.php");
	$P_ID = $_GET["P_ID"];
	$pname = $_POST["pname"];
	$ptype = $_POST["ptype"];
	$pcount = $_POST["pcount"];
	$psalary = $_POST["psalary"];
	$pquirment = $_POST["pquirment"];
	$sql = "update company_position set P_TYPE = '$ptype',P_NAME = '$pname',P_REQUIREMENT = '$pquirment',P_COUNT = $pcount,P_SALARY = '$psalary' where P_ID = $P_ID";//����ָ����λ��Ϣ
	get_connection();
	mysql_query($sql);
	if(mysql_affected_rows()==1)
		$message = "success";
	else
		$message = "fail";
	close_connection();
	header("Location:index.php?url=companyPosition_edit.php&message=$message&P_ID=$P_ID");
?>

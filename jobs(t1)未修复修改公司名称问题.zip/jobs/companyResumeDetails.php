<?php 
	header("content-Type: text/html; charset=gbk");
	include_once("functions/database.php");
	include_once("functions/is_login.php");
	if(isset($_GET["R_S_ACCOUNT"]))//����Ҫ��������ѧ���˺�
	{
		$R_S_ACCOUNT = $_GET["R_S_ACCOUNT"];
	}
	if(isset($_GET["P_ID"]))//����Ҫ��������ѧ���˺�
	{
		$P_ID = $_GET["P_ID"];
	}
	if(isset($_GET["page_current"])){
		$page_current = $_GET["page_current"];
	}else{
		$page_current = 1;
	}
	$name = $_SESSION["name"];//��ȡ��˾��
	$row = getResume($R_S_ACCOUNT);//ָ��ѧ���˺��¼�����������Ϣ
	$message = "";
	if(isset($_GET["message"]))
	{
		if($_GET["message"] == "success")
		{
			$message ="����ɹ�!";
		}
		else if($_GET["message"] == "fail")
		{
			$message ="����ʧ��!";
		}
	}
?>
<div class="container">
	<div class="news-list">
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 0px;">
			<legend>�鿴���� - ��˼���</legend>
		</fieldset>
		<form class="layui-form layui-form-pane" action="myResume_save.php" method="post">
			<div class="layui-form-item">
		    	<label class="layui-form-label">����</label>
		    	<div class="layui-input-inline">
		      		<input type="text" name="username" readonly lay-verify="required" placeholder="������" autocomplete="off" class="layui-input" value="<?php echo $row['R_NAME'];?>">
		    	</div>
		    	<label class="layui-form-label">����</label>
			    <div class="layui-input-inline">
			    	<input type="text" name="age" readonly lay-verify="required" placeholder="������" autocomplete="off" class="layui-input" value="<?php echo $row['R_AGE'];?>">
			    </div>
			    <label class="layui-form-label">����</label>
			    <div class="layui-input-inline">
			    	<input type="text" name="place" readonly lay-verify="required" placeholder="������" autocomplete="off" class="layui-input" value="<?php echo $row['R_PLACE'];?>">
			    </div>
			</div>
		  	<div class="layui-form-item">
		  		<label class="layui-form-label">ѧ��</label>
			   	<div class="layui-input-inline">
			    	<select name="edu">
				        <option value="0" selected>��ѡ��</option>
				        <option value="��ʿ" <?php if($row['R_EDUCATION']=="��ʿ")echo "selected";?>>��ʿ</option>
				        <option value="˶ʿ" <?php if($row['R_EDUCATION']=="˶ʿ")echo "selected";?>>˶ʿ</option>
				        <option value="����" <?php if($row['R_EDUCATION']=="����")echo "selected";?>>����</option>
				        <option value="��ר" <?php if($row['R_EDUCATION']=="��ר")echo "selected";?>>��ר</option>
				        <option value="��ר" <?php if($row['R_EDUCATION']=="��ר")echo "selected";?>>��ר</option>
			      	</select>
			    </div>
			 	<label class="layui-form-label">ѧУ</label>
			    <div class="layui-input-inline">
			    	<input type="text" name="school" readonly lay-verify="required" placeholder="������" autocomplete="off" class="layui-input" value="<?php echo $row['R_SCHOOL'];?>">
			 	</div>
			 	<label class="layui-form-label">רҵ</label>
			    <div class="layui-input-inline">
			    	<input type="text" name="major" readonly lay-verify="required" placeholder="������" autocomplete="off" class="layui-input" value="<?php echo $row['R_MAJOR'];?>">
			 	</div>
		 	</div>
		 	<div class="layui-form-item" pane="">
			    <label class="layui-form-label">�Ա�</label>
			    <div class="layui-input-block">
			        <input type="radio" name="sex"  value="��" title="��" <?php if($row['R_SEX']=="��")echo "checked";?>>
			        <input type="radio" name="sex"  value="Ů" title="Ů" <?php if($row['R_SEX']=="Ů")echo "checked";?>>
			    </div>
		  	</div>
		  	<div class="layui-form-item layui-form-text">
		   		<label class="layui-form-label">��������</label>
		    	<div class="layui-input-block">
		     		<textarea name="experiences" readonly placeholder="��:��������ѧԺ     2016.9.1 - 2019.6.30" class="layui-textarea"><?php echo $row['R_EDU_EXPERIENCE'];?></textarea>
		    	</div>
		  	</div>
		  	<div class="layui-form-item layui-form-text">
		   		<label class="layui-form-label">����</label>
		    	<div class="layui-input-block">
		     		<textarea name="skills" readonly  placeholder="������" class="layui-textarea"><?php echo $row['R_SKILLS'];?></textarea>
		    	</div>
		  	</div>
		  	<div class="layui-form-item layui-form-text">
		   		<label class="layui-form-label">�񽱺�֤��</label>
		    	<div class="layui-input-block">
		     		<textarea name="certificate" readonly  placeholder="������" class="layui-textarea"><?php echo $row['R_CERTIFICATE'];?></textarea>
		    	</div>
		  	</div>
		   <div class="layui-form-item layui-form-text">
		   		<label class="layui-form-label">��������</label>
		    	<div class="layui-input-block">
		     		<textarea name="evaluate" readonly  placeholder="������" class="layui-textarea"><?php echo $row['R_SELF_EVALUATE'];?></textarea>
		    	</div>
		  	</div>
		    <div class="layui-form-item">
			    <div class="layui-inline">
				    <label class="layui-form-label">����н��</label>
				    <div class="layui-input-inline" style="width: 100px;">
				    	<input type="text" name="salary_min" readonly placeholder="��" autocomplete="off" class="layui-input" value="<?php echo $row['SALARY_MIN'];?>">
				    </div>
				    <div class="layui-form-mid">-</div>
				    <div class="layui-input-inline" style="width: 100px;">
				    	<input type="text" name="salary_max" readonly placeholder="��" autocomplete="off" class="layui-input" value="<?php echo $row['SALARY_MAX'];?>">
				    </div>
				    <label class="layui-form-label">��ϵ��ʽ</label>
			    	<div class="layui-input-inline">
			      		<input type="text" name="phone" readonly lay-verify="required" placeholder="��������ϵ��ʽ" autocomplete="off" class="layui-input" value="<?php echo $row['R_PHONE'];?>">
			    	</div>
			    	<label class="layui-form-label">����</label>
			    	<div class="layui-input-inline">
			      		<input type="text" name="mail" readonly lay-verify="required" placeholder="����������" autocomplete="off" class="layui-input" value="<?php echo $row['R_MAIL'];?>">
			    	</div>
		    	</div>
		    	����:<a href="download.php?attachment=<?php echo urlencode($row['attachment']);?>"><?php echo $row['attachment'];?></a>
		  	</div>
  		</form> 
  		<div class="layui-btn-group">
			
				<a style="float:left;" href = "index.php?url=companyResumeDetailsProcess.php&R_S_ACCOUNT=<?php echo $row['R_S_ACCOUNT']?>&page_current=<?php echo $page_current?>&P_ID=<?php echo $P_ID?>&tip=1" >
					<p style='text-align: center;'><font color="white">
						<button type="button" class="layui-btn layui-btn">ͨ��</button>
					</font></p>
				</a>
			
			
				<a href = "index.php?url=companyResumeDetailsProcess.php&R_S_ACCOUNT=<?php echo $row['R_S_ACCOUNT']?>&page_current=<?php echo $page_current?>&P_ID=<?php echo $P_ID?>&tip=0" >
					<font color="white">
						<button type="button" class="layui-btn layui-btn">����</button>
					</font>
				</a>
			
			
				<a href = "index.php?url=companyReceive.php&page_current=<?php echo $page_current?>" >
					<font color="white">
						<button type="button" class="layui-btn layui-btn">����</button>
					</font>
				</a>
			
		</div>
	</div>
</div>
<script>
		layui.use(['form', 'layedit', 'laydate'], function(){
		  var form = layui.form
		  ,layer = layui.layer
		  ,layedit = layui.layedit
		  ,laydate = layui.laydate;
		  
		  //����
		  laydate.render({
		    elem: '#date'
		  });
		  laydate.render({
		    elem: '#date1'
		  });
		  
		  //����һ���༭��
		  var editIndex = layedit.build('LAY_demo_editor');
		 
		  //�Զ�����֤����
		  form.verify({
		    title: function(value){
		      if(value.length < 5){
		        return '�������ٵ�5���ַ���';
		      }
		    }
		    ,pass: [
		      /^[\S]{6,12}$/
		      ,'�������6��12λ���Ҳ��ܳ��ֿո�'
		    ]
		    ,content: function(value){
		      layedit.sync(editIndex);
		    }
		  });
		  
		  //����ָ������
		  form.on('switch(switchTest)', function(data){
		    layer.msg('����checked��'+ (this.checked ? 'true' : 'false'), {
		      offset: '6px'
		    });
		    layer.tips('��ܰ��ʾ����ע�⿪��״̬�����ֿ������ⶨ�壬����������ON|OFF', data.othis)
		  });
		  
		  //�����ύ
		  form.on('submit(demo1)', function(data){
		    layer.alert(JSON.stringify(data.field), {
		      title: '���յ��ύ��Ϣ'
		    })
		    return false;
		  });
		 
		  //������ֵ
		  layui.$('#LAY-component-form-setval').on('click', function(){
		    form.val('example', {
		      "username": "����" // "name": "value"
		      ,"password": "123456"
		      ,"interest": 1
		      ,"like[write]": true //��ѡ��ѡ��״̬
		      ,"close": true //����״̬
		      ,"sex": "Ů"
		      ,"desc": "�Ұ� layui"
		    });
		  });
		  
		  //����ȡֵ
		  layui.$('#LAY-component-form-getval').on('click', function(){
		    var data = form.val('example');
		    alert(JSON.stringify(data));
		  });
		  
		});
</script>  
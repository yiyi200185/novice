<?php
	header("content-Type: text/html; charset=gbk");
	include_once("functions/is_login.php");
	include_once("functions/database.php");
	if(!session_id()){
		session_start();
	}
	if(!is_login()){
		echo "������¼ϵͳ��,�ٷ��ʸ�ҳ��!";
		return;
	}
	$userName = $_SESSION["userName"];
	$cname = $_POST["cname"] == "" ? "" : $_POST["cname"];
	$socialCode = $_POST["socialCode"] == "" ? "" : $_POST["socialCode"];
	$caddress = $_POST["caddress"] == "" ? "" : $_POST["caddress"];
	$cdesc = $_POST["cdesc"] == "" ? "" : $_POST["cdesc"];
	$cphone = $_POST["cphone"] == "" ? "" : $_POST["cphone"];
	$cmail = $_POST["cmail"] == "" ? "" : $_POST["cmail"];
	get_connection();
	$sql = "update company_info SET C_NAME = '$cname',SOCIAL_CODE ='$socialCode',C_ADDRESS ='$caddress',C_INTRODUCTION ='$cdesc',C_PHONE ='$cphone',C_MAIL ='$cmail' WHERE C_ACCOUNT = '$userName' and DELETE_FLAG = 0";	
	mysql_query($sql);
	if(mysql_affected_rows() > 0){
		$message = "success";
	}
	else{
		$message = "fail";
	}
	header("Location:index.php?url=companyEdit.php&message=$message");

?>
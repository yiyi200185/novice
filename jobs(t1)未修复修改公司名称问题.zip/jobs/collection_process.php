<?php
	session_start();
	include_once("functions/database.php");
	if(isset($_GET['P_ID']))
	{
		$P_ID = $_GET['P_ID'];
	}
	if(isset($_GET['charge']))
	{
		$charge = $_GET['charge'];
	}
	if(isset($_GET['keyword']))
	{
		$keyword = $_GET['keyword'];
	}
	if(isset($_GET['page_current']))
	{
		$page_current = $_GET['page_current'];
	}
	if(isset($_GET['pageFlag']))//�жϷ���ҳ������ҳ�����ҵ��ղ�ҳ��
	{
		$pageFlag = $_GET['pageFlag'];
	}
	$userName = $_SESSION['userName'];
	
	if(is_exist_collect($P_ID, $userName))//����ղ��б����Ѵ��ڸ����ղ�
	{
		//ɾ��
		$sql = "DELETE FROM STUDENT_COLLECTION WHERE SC_S_ACCOUNT='$userName' and SC_P_ID='$P_ID'";
	}
	else
	{
		//��������ղ�
		$sql = "insert into STUDENT_COLLECTION values(null,'$userName','$P_ID')";	
	}
	get_connection();
	mysql_query($sql);
	if(mysql_affected_rows()!=0){
		if($pageFlag == 0)
		{
			header("Location:index.php?url=studentMainpage.php&mes=success&keyword=$keyword&charge=$charge&page_current=$page_current");
		}
		else if($pageFlag == 1)
		{
			header("Location:index.php?url=myCollection.php&mes=success&keyword=$keyword&charge=$charge&page_current=$page_current");
		}
	}
	else{
		header("Location:index.php?url=studentMainpage.php&mes=fail&keyword=$keyword&charge=$charge&page_current=$page_current");
	}
	close_connection();
?>
<?php
	include_once("functions/database.php");
	include_once("functions/is_login.php");
	if(!session_id()){
		session_start();
	}
	if(isset($_GET["page_current"])){
		$page_current = $_GET["page_current"];
	}else{
		$page_current = 1;
	}
	$P_ID = $_GET["P_ID"];
	get_connection();
	mysql_query("delete from company_position where P_ID=$P_ID");
	if(mysql_affected_rows()==1)
		$message = "success";
	else
		$message = "fail";
	close_connection();
	
	header("Location:index.php?url=companyPosition.php&message=$message&page_current=$page_current");
	?>
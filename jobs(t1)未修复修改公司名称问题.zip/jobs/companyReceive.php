<?php 
	header("content-Type: text/html; charset=gbk");
	include_once("functions/database.php");
	include_once("functions/is_login.php");
	include_once("functions/page.php");
	if(isset($_SESSION["name"]))//��ȡ��˾��
	{
		$name = $_SESSION["name"];
	}
	$search_sql = "SELECT * from company_position,SEND_RESUME WHERE SEND_P_ID = P_ID and P_C_NAME LIKE '$name' and DELETE_FLAG =0";//������˾�յ�������
	get_connection();	
	$resultAllSet = mysql_query($search_sql);	
	$total_records = mysql_num_rows($resultAllSet);	
	$page_size = 5;	
	if(isset($_GET["page_current"])){
		$page_current = $_GET["page_current"];
	}else{
		$page_current = 1;
	}	
	$start = ($page_current - 1) * $page_size;	
	$search_sql = "SELECT * from company_position,SEND_RESUME,student_resume WHERE SEND_P_ID = P_ID  and SEND_S_ACCOUNT = R_S_ACCOUNT and P_C_NAME LIKE '$name' and company_position.DELETE_FLAG = 0 AND student_resume.DELETE_FLAG = 0 order by SEND_STATUS,SEND_ID desc limit $start, $page_size";	
	$result_set = mysql_query($search_sql);	
	$emptyFlag = 1;//�з����������ݱ�־
	if(mysql_num_rows($result_set) == 0)
	{
		$emptyFlag = 0;//�޷����������ݱ�־
	}
	close_connection();
	$keyword = "";
	$charge= 0;
?>
<div class="container">
	<div class="news-list">
		<div class="news-list-item">
			<fieldset class="layui-elem-field layui-field-title" style="margin-top: 0px;">
		 		<legend>���״̬</legend>
			</fieldset> 
			<table class="layui-table" lay-skin="line">
				<colgroup>
				    <col class="col">
				    <col class="col">
				    <col class="col">
				    <col class="col">
				    <col class="col">
				    <col class="col">
				    <col class="col">
			  	</colgroup>
			  	<thead>
				    <tr>
				      	<th width="60">����</th>
				     	<th width="60">����</th>
				    	<th width="60">ѧ��</th>
				    	<th width="60">רҵ</th>
				    	<th width="60">ӦƸ��λ</th>
				    	<th width="60">���� </th>
				    	<th width="60">���״̬ </th>
				    </tr> 
			  	</thead>
				<?php 
					if($emptyFlag)
					{
				?>
				<tbody>
					<?php
						while($row = mysql_fetch_array($result_set))
						{
					?>
					<tr>
						<td><?php echo $row['R_NAME']?></td>
						<td><?php echo $row['R_AGE']?></td>
						<td><?php echo $row['R_EDUCATION']?></td>
						<td><?php echo $row['R_MAJOR']?></td>
						<td><?php echo $row['P_NAME']?></td>
						<td>
							<div class="layui-btn-group">
							  		
							  			<a href = "index.php?url=companyResumeDetails.php&R_S_ACCOUNT=<?php echo $row['R_S_ACCOUNT']?>&page_current=<?php echo $page_current?>&P_ID=<?php echo $row['P_ID']?>" >
							  				<font color="white">
												<button type="button" class="layui-btn layui-btn-sm">�鿴����</button>
							  				</font>
							  			</a>
							 		
							 </div>
						</td>
						<td>
						<?php 
							if($row['SEND_STATUS'] == 2)//�ж��Ƿ����ͨ��
							{
								echo "���ͨ��";
							}
							if($row['SEND_STATUS'] == 1)
							{
								echo "δͨ��";
							}
							else if($row['SEND_STATUS'] == 0)
							{ 
								echo "<strong><font color='black'>�����</font></strong>";
							} 
						?>
						</td>				
					</tr>	            
					<?php
						}
					?>
				</tbody>
				<?php 
					}
				?>
			</table>
			<div class="divpage">
	   			<?php
		   			if(mysql_num_rows($result_set) != 0)
		   			{
						$url = $_SERVER["PHP_SELF"]."?url=companyReceive.php";
						//echo $url;
						page($total_records, $page_size, $page_current, $url, null ,null);
						//echo $total_records."-".$page_size."-".$page_current."-".$url."-".$keyword;
					}
				?>
	   		</div>
	   	</div>
	</div>
</div>
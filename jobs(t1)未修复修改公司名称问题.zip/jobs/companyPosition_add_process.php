<?php
	include_once("functions/database.php");
	include_once("functions/is_login.php");
	session_start();
	if(isset($_SESSION["name"]))
	{
		$cname = $_SESSION["name"];//�û���
	}
	$pname = $_POST["pname"];
	$ptype = $_POST["ptype"];
	$pcount = $_POST["pcount"];
	$psalary = $_POST["psalary"];
	$pquirment = $_POST["pquirment"];
	$sql = "insert into company_position values(null,'$cname','$ptype','$pname','$pquirment',$pcount,0,0,'$psalary',0);";//����һ����λ
	get_connection();
	mysql_query($sql);
	if(mysql_affected_rows()==1)
		$message = "success";
	else
		$message = "fail";
	close_connection();
	header("Location:index.php?url=companyPosition.php&message=$message");
?>
